import pandas as pd
import os
from pathlib import Path
import re
import csv
import openai
from flask import Flask, render_template, request
import io
import sys

app = Flask(__name__)
# clé API OpenAI
openai.api_key = "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"

# Liste des personnalités
personnalites = {
    
            "Architecte": "static/assets/analyste_architecte.svg",
            "Logicien": "static/assets/analyste_logicien.svg",
            "Commandant": "static/assets/analyste_commandant.svg",
            "Innovateur": "static/assets/analyste_innovateur.svg",
            "Avocat": "static/assets/diplomate_avocat.svg",
            "Mediateur": "static/assets/diplomate_mediateur.svg",
            "Protagoniste": "static/assets/diplomate_protagoniste.svg",
            "Inspirateur": "static/assets/diplomate_inspirateur.svg",
            "Logisticien": "static/assets/sentinelle_logisticien.svg",
            "Defenseur": "static/assets/sentinelle_defenseur.svg",
            "Directeur": "static/assets/sentinelle_directeur.svg",
            "Consul": "static/assets/sentinelle_consul.svg",
            "Virtuose": "static/assets/explorateur_virtuose.svg",
            "Aventurier": "static/assets/explorateur_aventurier.svg",
            "Entrepreneur": "static/assets/explorateur_entrepreneur.svg",
            "Amuseur": "static/assets/explorateur_amuseur.svg"
                    
                 }


def selectionner_niveau():
    return request.form["level"]

def selectionner_centres_interets():
    return request.form["interests"]

def selectionner_personnalite():
    return request.form["personality"]




def generer_prompt1(level, personality, titles, interests):
    titles_str = ', '.join(titles)
    prompt = (
        f"My proficiency level is {level}, and according to the 16 Personalities test from the site https://www.16personalities.com, my personality type is {personality}. My interests include {interests}. "
        f"From this list of themes : {titles_str}, please select the titles that matches the most my {interests}."
        f"The expected response is a list in the format [title1, title2, ..., titleN], consisting solely of items from the list of themes. No additional sentences or explanations are necessary."
        f"The result must only be from the {titles_str}. Your job is only to matches this list with my {interests}. Ensure to select as many titles as possible from {titles_str} that align with my {interests}."
        f"Everything must be conducted in French."
    )
    return prompt


""" f"My proficiency level is {level}, and according to the 16 Personalities test from the site https://www.16personalities.com, my personality type is {personality}. My interests include {interests}. "
        f"I request you to directly compare my interests against this list of themes: {titles_str}. Please select and provide only the titles from the list that best match my interests and personality type."
        f"The expected response is a list in the format [title1, title2, ..., titleN], consisting solely of items from the list of themes. No additional sentences or explanations are necessary."
        f"You must choose at least 2 or 3 themes from the list, but no more than 4, selecting fewer if appropriate."
        f"The generated list should only include themes from the provided list of titles: {titles_str}."
        f"Your role is to provide the list that best matches my interests. Ensure to select as many titles as possible from {titles_str} that align with my {interests}."
        f"Everything must be conducted in French."""

def generer_prompt2(level, personality, interests, df_filtered3):
    prompt = (
        f"I am at level {level} with a personality of {personality}. My interests include {interests}. "
        f"Please analyze the following dataframe: {df_filtered3.to_string(index=False)}. From this data, return a list of IDs that correspond to my personality and interests."
        f"I want only one ID per resource, and avoid selecting two resources that are too similar."
        f"Make sure to provide only the IDs based on personality and interests, without any additional explanation."
        f"Make sure to select ressources that have different title from the dataframe : {df_filtered3.to_string(index=False)}."
        f"You must do it all in French."
    )
    return prompt


def obtenir_reponse_gpt1(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant. Use the provided data on personality and interests to generate a list of relevant keywords. Select only the elements that match the user's personality and interests. Each element should be retrieved from the list of themes without adding any additional explanation or context."},
            {"role": "user", "content": prompt}
        ],
        n=1,
        temperature=0.7,
        stop=None
    )
    content = response['choices'][0]['message']['content']
    print("Réponse du modèle pour le prompt 1:", content)
    return content


def obtenir_reponse_gpt2(prompt2):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant. You will analyze the provided dataframe and generate a list of IDs based on  personality  interests. You will provide a minimum of 6 resources or more"},
            {"role": "user", "content": prompt2}
        ],
        n=1,
        temperature=0.7,
        stop=None
    )
    content = response['choices'][0]['message']['content']
    print("Réponse du modèle pour le prompt 2:", content)
    return content

def find_info_by_id_csv(resource_id, chemins_csv):
    resource_id = resource_id.strip().strip('"')
    for chemin_csv in chemins_csv:
        try:
            with open(chemin_csv, 'r', encoding='utf-8') as csv_file:
                csv_reader = csv.DictReader(csv_file)
                for row in csv_reader:
                    if row.get('id', '').strip() == resource_id:
                        info = {
                            "title": row.get('title', ''),
                            "titles" : row.get('titles', ''),
                            "summary": row.get('summary', ''),
                            "path": chemin_csv,
                            "links": row.get('links', '') , # Ajout de la récupération du lien
                            "time_min" : row.get('time_min', '')
                        }
                        print(f"Info for ID {resource_id}: {info['title']}")
                        return info
        except FileNotFoundError:
            print(f"File {chemin_csv} not found.")
            continue
        except Exception as e:
            print(f"An error occurred while processing file {chemin_csv}: {e}")
            continue
    
    # Retourner None si l'ID n'est pas trouvé
    print(f"No info found for ID {resource_id}")
    return None

def traiter_reponse_gpt(content):
    try:
        resultat_liste = content.strip('[]').split(', ')
        resultat_liste = [elem.strip("'") for elem in resultat_liste]
        return resultat_liste
    except Exception as e:
        print(f"Une erreur s'est produite lors de la conversion de la réponse en liste: {e}")
        return []


def charger_et_preparer_donnees(chemins_csv, capacite_modele=4096):
    dfs = []
    for chemin in chemins_csv:
        try:
            print(f"Chemin vers le fichier CSV : {chemin}")
            df = pd.read_csv(chemin)
            if 'descriptions' in df.columns and 'id' in df.columns and 'titles' in df.columns:  
                # Convertir les colonnes 'descriptions', 'id' et 'titles' en chaînes de caractères
                df['descriptions'] = df['descriptions'].astype(str)
                df['id'] = df['id'].astype(str)
                df['title'] = df['title'].astype(str)  
                df['time_min'] = df["time_min"].astype(str)

                # Calculer le nombre de tokens pour chaque entrée
                df['nombre_tokens'] = df['descriptions'].str.len() + df['id'].str.len() + df['titles'].str.len() + df["time_min"].str.len()  # Incluez la colonne 'titles' dans le calcul

                # Sélectionner uniquement les colonnes nécessaires
                df_filtered = df.loc[:, ['id', 'title', 'descriptions', 'nombre_tokens']]

                # Diviser les données en chunks en respectant la capacité du modèle
                current_chunk = []
                current_chunk_tokens = 0
                for index, row in df_filtered.iterrows():
                    if current_chunk_tokens + row['nombre_tokens'] <= capacite_modele:
                        current_chunk.append(row)
                        current_chunk_tokens += row['nombre_tokens']
                    else:
                        # Traitement du chunk actuel
                        chunk_df = pd.DataFrame(current_chunk)
                        dfs.append(chunk_df)
                        # Réinitialiser le chunk actuel
                        current_chunk = [row]
                        current_chunk_tokens = row['nombre_tokens']

                # Traitement du chunk restant
                if current_chunk:
                    chunk_df = pd.DataFrame(current_chunk)
                    dfs.append(chunk_df)

        except FileNotFoundError as e:
            print(f"Fichier non trouvé : {e}")
            continue

    # Concaténer les résultats de chaque chunk
    if dfs:
        df_merged = pd.concat(dfs, ignore_index=True)
    else:
        df_merged = pd.DataFrame()

    return df_merged

def ajuster_df_pour_limite_tokens(df, limite_tokens=16384, taille_description=200):
    # Tronquer les descriptions à une longueur maximale
    df['descriptions'] = df['descriptions'].apply(lambda x: x[:taille_description] if len(x) > taille_description else x)
    
    tokens_actuels = sum(df['descriptions'].apply(len)) + sum(df['title'].apply(len))
    
    if tokens_actuels > limite_tokens:
        # Calculer le nombre moyen de tokens par ligne
        tokens_moyens_par_ligne = tokens_actuels / len(df)
        
        # Estimer le nombre de lignes à conserver pour rester sous la limite
        lignes_a_conserver = int(limite_tokens / tokens_moyens_par_ligne)
        
        # Réduire le nombre de lignes si nécessaire
        df_reduit = df.iloc[:lignes_a_conserver]
    else:
        df_reduit = df

    return df_reduit

def generer_synthese_des_resumes(infos):
    # Cette fonction combine tous les résumés pour créer une synthèse générale.
    return " ".join(info.get('summary', '') for info in infos)


def obtenir_synthese_gpt3(texte_concatene, type_section,infos):
    # Cette fonction fait l'appel API à GPT-3 pour obtenir une synthèse.
    resume = generer_synthese_des_resumes(infos)
    if type_section == 'intro':
        prompt = (
            f'Parse the following dataframe :f"{resume} , and write a course introduction based on the dataframe. Do not mention any resource, but rather explain what will be seeing globally using the informations from the dataframe. Write the introduction in French. The first sentence you say in your response will be as follows : "L''équipe BTC TouchPoint vous remercie d''utiliser cette nouvelle plateforme de formation personnalisée"'
        )
    else:  # conclusion
        prompt = (
            "Après avoir examiné et discuté de plusieurs sujets importants dans ce cours, "
            "rédigez une conclusion qui synthétise ce que nous avons appris. "
            f"{texte_concatene}"
        )

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,  # Vous pouvez ajuster le nombre de tokens selon le besoin
        n=1,
        temperature=0.7,
        #stop=["\n"]  # Vous pouvez spécifier un token de fin si nécessaire
    )
    
    content = response.choices[0].message['content'].strip()
    return content

def generer_prompt_plan_de_cours(infos):
    # Créez une concaténation des résumés pour l'introduction et la conclusion.
    texte_concatene = generer_synthese_des_resumes(infos)

    # Obtenir l'introduction et la conclusion en utilisant GPT-3.
    introduction = obtenir_synthese_gpt3(texte_concatene, 'intro')
    conclusion = obtenir_synthese_gpt3(texte_concatene, 'conclu')

    # Générer les titres des parties avec un résumé pour chaque partie.
    parties = ""
    for i, info in enumerate(infos, 1):
        titre_partie = info.get('titles', f"Titre Partie {i}")
        resume_partie = info.get('summary', '')
        parties += f"Partie {i}: {titre_partie}\n{resume_partie}\n\n"

    # Créer le prompt à partir de l'introduction, des parties et de la conclusion.
    prompt_plan_de_cours = (
        "Voici la structure proposée pour le plan de cours :\n\n"
        f"Introduction:\n\n{introduction}\n\n"
        f"{parties}"
        f"Conclusion:\n\n{conclusion}\n\n"
        "L'ensemble doit être rédigé en français. Tu donneras un nom différent à chaque partie, qui se rapproche de l'article associé"
    )

    return prompt_plan_de_cours


# def obtenir_plan_de_cours(introduction, conclusion, infos):
#     # Supprimer la première phrase de l'introduction
#     #introduction = remove_first_sentence(introduction)
    
#     # Rediriger la sortie standard vers une chaîne
#     output = io.StringIO()
#     sys.stdout = output
    
#     # Imprimer l'introduction générée
#     print("Introduction:\n")
#     print(f"{introduction}\n")

#     # Imprimer les titres et les résumés avec les liens pour chaque partie
#     print("Parties:\n")
#     for i, info in enumerate(infos, 1):
#         titre = info.get('title', f"Titre Partie {i}")
#         resume = info.get('summary', '')
#         lien = info.get('links', '')
#         if titre and resume:
#             print(f"Partie {i} - {titre}:\n{resume}\n")
#             if lien:
#                 print(f"Lien: {lien}\n")

#     # Imprimer la conclusion générée
#     print("Conclusion:\n")
#     print(f"{conclusion}\n")
    
#     # Récupérer la sortie capturée
#     output_string = output.getvalue()
    
#     # Rétablir la sortie standard
#     sys.stdout = sys.__stdout__
    
#     return output_string

#_______________________________________________________________________________

def obtenir_plan_de_cours(introduction, conclusion, infos):
    plan_de_cours = {
        "Introduction": introduction,
        "Parties": {},
        "Conclusion": conclusion
    }
    
    # Ajouter les informations de chaque partie
    for i, info in enumerate(infos, 1):
        titre = info.get('titles', f"Titre Partie {i}")
        resume = info.get('summary', '')
        lien = info.get('links', '')
        temps = info.get('time_min','')
        plan_de_cours["Parties"][f"Partie {i}- {titre}"] = {
            "Summary": resume,
            "Lien": lien,
            "Temps": temps
        }
    
    return plan_de_cours

#_______________________________________________________________________________


# def remove_first_sentence(text):
#     # Utilisation d'une expression régulière pour trouver la première phrase
#     first_sentence_pattern = r'^.*?[.!?]'
#     first_sentence_match = re.match(first_sentence_pattern, text)

#     # Si une correspondance est trouvée, supprimer la première phrase
#     if first_sentence_match:
#         first_sentence = first_sentence_match.group(0)
#         text = text[len(first_sentence):].strip()

#     return text



@app.route("/", methods=["GET", "POST"])
def main():
    resp = []  # Initialisation de la variable resp

    if request.method == "POST":
        df_filtered = pd.DataFrame()

        # Simuler les entrées de l'utilisateur
        level = selectionner_niveau()
        personality = selectionner_personnalite()
        interests = selectionner_centres_interets()

        # Liste des titres
        titles = [
            "systemes_monetaires",
            "changement_de_paradigme",
            "bitcoin_core___vue_d_ensemble",
            "parties_prenantes",
            "reseau_lightning",
            "energie",
            "agriculture",
            "science___recherche",
            "inclusion_sociale",
            "desintermediation",
            "education",
            "nutrition___sante",
            "droits___libertes",
            "politique",
            "racines_cypherpunk",
            "contre_culture",
            "liberte",
            "culture_financiere_pour_tous",
            "preference_temporelle",
            "recablage___mise_a_jour",
            "couverture_contre_l_inflation",
            "transferts_de_fonds_et_echange_de_devises",
            "progresser_pas_a_pas",
            "acheter_du_btc",
            "utiliser_un_wallet__porte_cles",
            "conserver_ses_sats_btc",
            "devenir_mineur_de_btc",
            "mon_commerce_et_bitcoin",
            "travailler_dans_bitcoin",
            "etre_paye_en_bitcoin",
            "eviter_les_pieges_et_arnaques",
            "securite",
            "generalites",
            "pour_les_particuliers",
            "utiliser_liquid",
            "nostr",
            "cycles_historiques",
            "stabilite_economique",
            "environnement",
            "mouvement_de_paix",
            "entrainement_emotionnel",
            "realisation_de_soi",
            "value4value__micropaiements__etc_",
            "verifier__auditer",
            "depenser__acheter",
            "economie_circulaire",
            "se_chauffer_en_minant",
            "confidentialite",
            "ordinals__stamps__brc_20____",
            "experimentations_ludiques",
            "l_ecosysteme_du_protocole_bitcoin",
            "integrite",
            "responsabilite",
            "arts",
            "referentiel_juste",
            "transactions_resistantes_a_la_censure",
            "faire_tourner_son_noeud",
            "pour_les_professionnels",
            "asphyxie_culturelle_fiat",
            "morale",
            "stoicisme",
            "protection_du_patrimoine",
            "emprunter",
            "crowfunding",
            "architecture",
        ]


        # Générer le prompt en utilisant les entrées simulées
        prompt = generer_prompt1(level, personality, titles, interests)
        content = obtenir_reponse_gpt1(prompt)
        resultat_liste = traiter_reponse_gpt(content)

        if isinstance(resultat_liste, list):
            level = level if level in [1, 2, 3] else 1
            chemins_csv = []

            for i in range(level, 3):
                chemin_dossier = f'niveau{i}'
                chemins_csv += [os.path.join(chemin_dossier, f"{element}.csv") for element in resultat_liste]

            df_filtered = charger_et_preparer_donnees(chemins_csv)
            print("premier df",df_filtered)
            df_filtered2 = df_filtered.sample(frac=1).reset_index(drop=True)
            print("deusieme df",df_filtered2)
            df_filtered3 = ajuster_df_pour_limite_tokens(df_filtered2)
            print("troisieme df", df_filtered3)


            if not df_filtered.empty:
                prompt2 = generer_prompt2(level, personality, interests, df_filtered3)
                content2 = obtenir_reponse_gpt2(prompt2)
                ids_regex = re.compile(r'\b[a-f0-9]{32}\b')
                ids = ids_regex.findall(str(content2))

                infos = []
                for resource_id in ids:
                    info = find_info_by_id_csv(resource_id, chemins_csv)
                    if info:
                        infos.append(info)

                if len(infos) < len(ids) and level > 1:
                    chemin_dossier = f'niveau{level-1}'
                    chemins_csv += [os.path.join(chemin_dossier, f"{element}.csv") for element in resultat_liste]
                    df_filtered = charger_et_preparer_donnees(chemins_csv)

                if not df_filtered.empty:
                    texte_concatene = generer_synthese_des_resumes(infos)
                    introduction_generée = obtenir_synthese_gpt3(texte_concatene, 'intro', infos)
                    conclusion_generée = obtenir_synthese_gpt3(texte_concatene, 'conclu', infos)

                    print(introduction_generée)
                    print('/n')
                    print(conclusion_generée)
                    resp = obtenir_plan_de_cours(introduction_generée, conclusion_generée, infos)
                    #print(resp)

        return render_template('response.html', resp=resp)

    return render_template('index.html', personnalites=personnalites)



if __name__ == "__main__":
    app.run(debug=True)
