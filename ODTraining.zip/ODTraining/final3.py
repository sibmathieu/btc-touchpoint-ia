import pandas as pd
import os
from pathlib import Path
import re
import csv
import openai
from flask import Flask, render_template, request
import io
import sys

app = Flask(__name__)
# clé API OpenAI
openai.api_key = "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"

# Liste des personnalités
personnalites = {
    
            "Architecte": "static/assets/analyste_architecte.svg",
            "Logicien": "static/assets/analyste_logicien.svg",
            "Commandant": "static/assets/analyste_commandant.svg",
            "Innovateur": "static/assets/analyste_innovateur.svg",
            "Avocat": "static/assets/diplomate_avocat.svg",
            "Mediateur": "static/assets/diplomate_mediateur.svg",
            "Protagoniste": "static/assets/diplomate_protagoniste.svg",
            "Inspirateur": "static/assets/diplomate_inspirateur.svg",
            "Logisticien": "static/assets/sentinelle_logisticien.svg",
            "Defenseur": "static/assets/sentinelle_defenseur.svg",
            "Directeur": "static/assets/sentinelle_directeur.svg",
            "Consul": "static/assets/sentinelle_consul.svg",
            "Virtuose": "static/assets/explorateur_virtuose.svg",
            "Aventurier": "static/assets/explorateur_aventurier.svg",
            "Entrepreneur": "static/assets/explorateur_entrepreneur.svg",
            "Amuseur": "static/assets/explorateur_amuseur.svg"
                    
                 }



def selectionner_niveau():
    return request.form["level"]

def selectionner_centres_interets():
    return request.form["interests"]

def selectionner_personnalite():
    return request.form["personality"]




def generer_prompt1(level, personality, titles, interests):
    titles_str = ', '.join(titles)
    prompt = (
        f"My proficiency level is {level}, and according to the 16 Personalities test from the site https://www.16personalities.com/fr, my personality is {personality}. My interests include {interests}. "
        f"I'd like you to generate a non-exhaustive list of keywords related to my interests. Then, compare these keywords with a predefined list of themes and provide only the items that match both my personality and interests. Here's the list of themes: {titles_str}."
        f"I want you to select only the elements that align with my personality and interests. The response should be in the form of [element1, element2, ..., elementN], and each element MUST BE RETRIEVED FROM THE LIST OF THEMES, as if you're refining the list of themes, without any sentences or explanations."
        f"You must select at least 2 or 3 themes from the list."
        f" THE LIST YOU WILL GENERATE MUST BE THEMES FROM THE LIST OF TITLES: {titles_str}"
        f"You're role is only to provide the list that matches the most my {interests}. Make sure to do a list of as musch possible {titles_str} that matches my {interests}."
        f"You must do it all in french."
    )
    return prompt

def generer_prompt2(level, personality, interests, df_filtered):
    prompt = (
        f"I am at level {level} with a personality of {personality}. My interests include {interests}. "
        f"Please analyze the following dataframe: {df_filtered.to_string(index=False)}. From this data, return a list of IDs that correspond to my personality and interests."
        f"I want only one ID per resource, and avoid selecting two resources that are too similar."
        f"Make sure to provide only the IDs based on personality and interests, without any additional explanation."
        f"If I have many {interests} make sure to select at least one or two ressources for each {interests}"
        f"You must do it all in French."
    )
    return prompt


def obtenir_reponse_gpt1(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant. Use the provided data on personality and interests to generate a list of relevant keywords. Select only the elements that match the user's personality and interests. Each element should be retrieved from the list of themes without adding any additional explanation or context."},
            {"role": "user", "content": prompt}
        ],
        n=1,
        temperature=0.7,
        stop=None
    )
    content = response['choices'][0]['message']['content']
    print("Réponse du modèle pour le prompt 1:", content)
    return content


def obtenir_reponse_gpt2(prompt2):
    max_tokens_per_request = 4096
    prompt_words = prompt2.split()
    current_tokens = 0
    current_chunk = []
    responses = []
    
    for word in prompt_words:
        current_chunk.append(word)
        current_chunk_length = len(' '.join(current_chunk))
        
        if current_chunk_length > max_tokens_per_request:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant. You will analyze the provided dataframe and generate a list of IDs based on personality interests. You will provide a minimum of 6 resources or more"},
                    {"role": "user", "content": ' '.join(current_chunk[:-1])}  # Retirer le dernier mot ajouté
                ],
                n=1,
                temperature=0.7,
                stop=None
            )
            content = response.choices[0].message['content']
            responses.append(content)
            
            current_chunk = [word]
        
        current_tokens = sum(len(word.split()) for word in responses) + current_chunk_length
        
        if current_tokens >= max_tokens_per_request:
            break
    
    if current_chunk:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant. You will analyze the provided dataframe and generate a list of IDs based on personality interests. You will provide a minimum of 6 resources or more"},
                {"role": "user", "content": ' '.join(current_chunk)}  # Ajouter le chunk actuel
            ],
            n=1,
            temperature=0.7,
            stop=None
        )
        content = response.choices[0].message['content']
        responses.append(content)
    
    return responses


def find_info_by_id_csv(resource_id, chemins_csv):
    resource_id = resource_id.strip().strip('"')
    for chemin_csv in chemins_csv:
        try:
            with open(chemin_csv, 'r', encoding='utf-8') as csv_file:
                csv_reader = csv.DictReader(csv_file)
                for row in csv_reader:
                    if row.get('id', '').strip() == resource_id:
                        info = {
                            "title": row.get('title', ''),
                            "titles" : row.get('titles', ''),
                            "summary": row.get('summary', ''),
                            "path": chemin_csv,
                            "links": row.get('links', '') , # Ajout de la récupération du lien
                            "time_min" : row.get('time_min', '')
                        }
                        print(f"Info for ID {resource_id}: {info['title']}")
                        return info
        except FileNotFoundError:
            print(f"File {chemin_csv} not found.")
            continue
        except Exception as e:
            print(f"An error occurred while processing file {chemin_csv}: {e}")
            continue
    
    # Retourner None si l'ID n'est pas trouvé
    print(f"No info found for ID {resource_id}")
    return None

def traiter_reponse_gpt(content):
    try:
        resultat_liste = content.strip('[]').split(', ')
        resultat_liste = [elem.strip("'") for elem in resultat_liste]
        return resultat_liste
    except Exception as e:
        print(f"Une erreur s'est produite lors de la conversion de la réponse en liste: {e}")
        return []


def charger_et_preparer_donnees(chemins_csv, capacite_modele=4096):
    dfs = []
    for chemin in chemins_csv:
        try:
            print(f"Chemin vers le fichier CSV : {chemin}")
            df = pd.read_csv(chemin)
            if 'descriptions' in df.columns and 'id' in df.columns and 'titles' in df.columns:  # Assurez-vous que la colonne 'titles' est présente
                # Convertir les colonnes 'descriptions', 'id' et 'titles' en chaînes de caractères
                df['descriptions'] = df['descriptions'].astype(str)
                df['id'] = df['id'].astype(str)
                df['titles'] = df['titles'].astype(str)  # Ajoutez cette ligne pour inclure la colonne 'titles'
                df['time_min'] = df["time_min"].astype(str)

                # Calculer le nombre de tokens pour chaque entrée
                df['nombre_tokens'] = df['descriptions'].str.len() + df['id'].str.len() + df['titles'].str.len() + df["time_min"].str.len()  # Incluez la colonne 'titles' dans le calcul

                # Diviser les données en chunks en respectant la capacité du modèle
                current_chunk = []
                current_chunk_tokens = 0
                for index, row in df.iterrows():
                    if current_chunk_tokens + row['nombre_tokens'] <= capacite_modele:
                        current_chunk.append(row)
                        current_chunk_tokens += row['nombre_tokens']
                    else:
                        # Traitement du chunk actuel
                        chunk_df = pd.DataFrame(current_chunk)
                        dfs.append(chunk_df)
                        # Réinitialiser le chunk actuel
                        current_chunk = [row]
                        current_chunk_tokens = row['nombre_tokens']

                # Traitement du chunk restant
                if current_chunk:
                    chunk_df = pd.DataFrame(current_chunk)
                    dfs.append(chunk_df)

        except FileNotFoundError as e:
            print(f"Fichier non trouvé : {e}")
            continue

    # Concaténer les résultats de chaque chunk
    if dfs:
        df_merged = pd.concat(dfs, ignore_index=True)
    else:
        df_merged = pd.DataFrame()

    return df_merged


def generer_synthese_des_resumes(infos):
    # Cette fonction combine tous les résumés pour créer une synthèse générale.
    return " ".join(info.get('summary', '') for info in infos)


def obtenir_synthese_gpt3(texte_concatene, type_section,infos):
    # Cette fonction fait l'appel API à GPT-3 pour obtenir une synthèse.
    resume = generer_synthese_des_resumes(infos)
    if type_section == 'intro':
        prompt = (
            f'Parse the following dataframe :f"{resume} , and write a course introduction based on the dataframe. Do not mention any resource, but rather explain what will be seeing globally using the informations from the dataframe. Write the introduction in French. The first sentence you say in your response will be as follows : "L''équipe BTC TouchPoint vous remercie d''utiliser cette nouvelle plateforme de formation personnalisée"'
        )
    else:  # conclusion
        prompt = (
            "Après avoir examiné et discuté de plusieurs sujets importants dans ce cours, "
            "rédigez une conclusion qui synthétise ce que nous avons appris. "
            f"{texte_concatene}"
        )

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=500,  # Vous pouvez ajuster le nombre de tokens selon le besoin
        n=1,
        temperature=0.7,
        #stop=["\n"]  # Vous pouvez spécifier un token de fin si nécessaire
    )
    
    content = response.choices[0].message['content'].strip()
    return content

def generer_prompt_plan_de_cours(infos):
    # Créez une concaténation des résumés pour l'introduction et la conclusion.
    texte_concatene = generer_synthese_des_resumes(infos)

    # Obtenir l'introduction et la conclusion en utilisant GPT-3.
    introduction = obtenir_synthese_gpt3(texte_concatene, 'intro')
    conclusion = obtenir_synthese_gpt3(texte_concatene, 'conclu')

    # Générer les titres des parties avec un résumé pour chaque partie.
    parties = ""
    for i, info in enumerate(infos, 1):
        titre_partie = info.get('titles', f"Titre Partie {i}")
        resume_partie = info.get('summary', '')
        parties += f"Partie {i}: {titre_partie}\n{resume_partie}\n\n"

    # Créer le prompt à partir de l'introduction, des parties et de la conclusion.
    prompt_plan_de_cours = (
        "Voici la structure proposée pour le plan de cours :\n\n"
        f"Introduction:\n\n{introduction}\n\n"
        f"{parties}"
        f"Conclusion:\n\n{conclusion}\n\n"
        "L'ensemble doit être rédigé en français. Tu donneras un nom différent à chaque partie, qui se rapproche de l'article associé"
    )

    return prompt_plan_de_cours


def obtenir_plan_de_cours(introduction, conclusion, infos):
    plan_de_cours = {
        "Introduction": introduction,
        "Parties": {},
        "Conclusion": conclusion
    }
    
    # Ajouter les informations de chaque partie
    for i, info in enumerate(infos, 1):
        titre = info.get('titles', f"Titre Partie {i}")
        resume = info.get('summary', '')
        lien = info.get('links', '')
        temps = info.get('time_min','')
        plan_de_cours["Parties"][f"Partie {i}- {titre}"] = {
            "Summary": resume,
            "Lien": lien,
            "Temps": temps
        }
    
    return plan_de_cours

@app.route("/", methods=["GET", "POST"])
def main():
    resp = []  # Initialisation de la variable resp

    if request.method == "POST":
        df_filtered = pd.DataFrame()

        # Simuler les entrées de l'utilisateur
        level = selectionner_niveau()
        personality = selectionner_personnalite()
        interests = selectionner_centres_interets()

        # Liste des titres
        titles = [
            "systemes_monetaires",
            "changement_de_paradigme",
            "bitcoin_core___vue_d_ensemble",
            "parties_prenantes",
            "reseau_lightning",
            "energie",
            "agriculture",
            "science___recherche",
            "inclusion_sociale",
            "desintermediation",
            "education",
            "nutrition___sante",
            "droits___libertes",
            "politique",
            "racines_cypherpunk",
            "contre_culture",
            "liberte",
            "culture_financiere_pour_tous",
            "preference_temporelle",
            "recablage___mise_a_jour",
            "couverture_contre_l_inflation",
            "transferts_de_fonds_et_echange_de_devises",
            "progresser_pas_a_pas",
            "acheter_du_btc",
            "utiliser_un_wallet__porte_cles",
            "conserver_ses_sats_btc",
            "devenir_mineur_de_btc",
            "mon_commerce_et_bitcoin",
            "travailler_dans_bitcoin",
            "etre_paye_en_bitcoin",
            "eviter_les_pieges_et_arnaques",
            "securite",
            "generalites",
            "pour_les_particuliers",
            "utiliser_liquid",
            "nostr",
            "cycles_historiques",
            "stabilite_economique",
            "environnement",
            "mouvement_de_paix",
            "entrainement_emotionnel",
            "realisation_de_soi",
            "value4value__micropaiements__etc_",
            "verifier__auditer",
            "depenser__acheter",
            "economie_circulaire",
            "se_chauffer_en_minant",
            "confidentialite",
            "ordinals__stamps__brc_20____",
            "experimentations_ludiques",
            "l_ecosysteme_du_protocole_bitcoin",
            "integrite",
            "responsabilite",
            "arts",
            "referentiel_juste",
            "transactions_resistantes_a_la_censure",
            "faire_tourner_son_noeud",
            "pour_les_professionnels",
            "asphyxie_culturelle_fiat",
            "morale",
            "stoicisme",
            "protection_du_patrimoine",
            "emprunter",
            "crowfunding",
            "architecture",
        ]



        # Générer le prompt en utilisant les entrées simulées
        prompt = generer_prompt1(level, personality, titles, interests)
        content = obtenir_reponse_gpt1(prompt)
        resultat_liste = traiter_reponse_gpt(content)

        if isinstance(resultat_liste, list):
            level = level if level in [1, 2, 3] else 1
            chemins_csv = []

            for i in range(level, 3):
                chemin_dossier = f'niveau{i}'
                chemins_csv += [os.path.join(chemin_dossier, f"{element}.csv") for element in resultat_liste]

            df_filtered = charger_et_preparer_donnees(chemins_csv)

            if not df_filtered.empty:
                prompt2 = generer_prompt2(level, personality, interests, df_filtered)
                content2 = obtenir_reponse_gpt2(prompt2)
                ids_regex = re.compile(r'\b[a-f0-9]{32}\b')
                ids = ids_regex.findall(str(content2))

                infos = []
                for resource_id in ids:
                    info = find_info_by_id_csv(resource_id, chemins_csv)
                    if info:
                        infos.append(info)

                if len(infos) < len(ids) and level > 1:
                    chemin_dossier = f'niveau{level-1}'
                    chemins_csv += [os.path.join(chemin_dossier, f"{element}.csv") for element in resultat_liste]
                    df_filtered = charger_et_preparer_donnees(chemins_csv)

                if not df_filtered.empty:
                    texte_concatene = generer_synthese_des_resumes(infos)
                    introduction_generée = obtenir_synthese_gpt3(texte_concatene, 'intro', infos)
                    conclusion_generée = obtenir_synthese_gpt3(texte_concatene, 'conclu', infos)

                    resp = obtenir_plan_de_cours(introduction_generée, conclusion_generée, infos)
                    print(resp)

        return render_template('response.html', resp=resp)

    return render_template('index.html', personnalites=personnalites)


if __name__ == "__main__":
    app.run(debug=True)
